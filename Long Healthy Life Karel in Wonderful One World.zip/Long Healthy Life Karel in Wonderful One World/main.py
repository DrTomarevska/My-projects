from karel.stanfordkarel import *
"""Long healthy life Karel. Karel's life is demonsrates 
the moves and possibilities, creative fun work 
in one interesting world. Karel can draw these levels 
and to put point beeper signs for knowledge of each health level 
in accordance with functional capabilities, good rehabilitation
and treatment, daily physical and cognitive activity, 
well-being and physical training. 1. https://doi.org/10.47855/jal9020-2023-3-3 
2. https://doi.org/10.47855/jal9020-2022-1-3 """
def main():
    birth_growth_education()
    blue_sky()
    wheat_field()
    rest()
    health_level()
    red()
    orange()
    yellow()
    lime()
    green()

"""Karel is studying. """
def birth_growth_education():
    turn_left()
    move_to_wall()
    turn_right()

"""Karel is painting or flying in the sky."""   
def blue_sky():
    while front_is_clear():
        paint_corner("DeepSkyBlue")
        move()
    paint_corner("DeepSkyBlue")
    turn_right()
    move()
    turn_right()
    while front_is_clear():
        paint_corner("LightSkyBlue")
        move()
    paint_corner("LightSkyBlue")
    turn_left()
    move()
    turn_left()
    while front_is_clear():
        paint_corner("PowderBlue")
        move()
    paint_corner("PowderBlue")
    turn_right()
    move()
    turn_right()
    while front_is_clear():
        paint_corner("PaleTurquoise")
        move()
    paint_corner("PaleTurquoise")
    turn_left()
    move()
    turn_left()
    while front_is_clear():
        paint_corner("LightCyan")
        move()
    paint_corner("LightCyan")

"""Karel plants wheat or a garden in the field."""
def wheat_field():
    turn_right()
    move()
    turn_right()
    while front_is_clear():
        paint_corner("LightYellow")
        move()
    paint_corner("LightYellow")
    turn_left()
    move()
    turn_left()
    while front_is_clear():
        paint_corner("LemonChiffon")
        move()
    paint_corner("LemonChiffon")
    turn_right()
    move()
    turn_right()
    while front_is_clear():
        paint_corner("LightGoldenrodYellow")
        move()
    paint_corner("LightGoldenrodYellow")
    turn_left()
    move()
    turn_left()
    while front_is_clear():
        paint_corner("PaleGoldenrod")
        move()
    paint_corner("PaleGoldenrod")
    turn_right()
    move()
    turn_right()
    while front_is_clear():
        paint_corner("Gold")
        move()
    paint_corner("Gold")

"""Karel rests in order to reach new horizons over and over."""
def rest():
    turn_right()
    if corner_color_is("LightCyan"):
        turn_left()
    else:
        for i in range(5):
            move()
    turn_right()
    for i in range(5):
        move()


"""Karel knows the secrets of determining and improving 
health with age by his example."""
def health_level():
    paint_corner("green")
    move()
    paint_corner("lime")
    move()
    paint_corner("yellow")
    move()
    paint_corner("orange")
    move()
    paint_corner("red")
    turn_right()

"""Karel is need medical and social help, passive moving
in this health level"""
def red():
    move()
    put_beeper()
    turn_right()

"""Karel is need the active rehabilitation and diagnosis of your 
health, light physical activity in this health level"""
def orange():
    move()
    paint_corner("orange")
    put_beeper()
    move()

"""Kare is need to pay especially attention to physical activity, 
deep breathing exercises and detail consultation by physician 
in this health level"""
def yellow(): 
    turn_left()
    turn_right()
    paint_corner("yellow")
    put_beeper()
    move()

"""Karel is need to harmonize the optimal relationship between  rest  
and  work, physical training and deep breathing  exercises in 
this health level"""
def lime():
    turn_left()
    for i in range(4):
        move()
    turn_right()
    turn_right()
    for i in range(4):
        move()
    paint_corner("lime")    
    put_beeper()
    turn_left()  

"""Healthy, physical and deep breathing training in 
this health level"""
def green():
    move_to_wall()
    turn_arround()
    while no_beepers_present():
        move()
    turn_right()
    turn_right()
    move()    
    put_beeper()
    paint_corner("green")
    turn_arround()
        
        
def move_to_wall():
    while front_is_clear():
        move()

def turn_right():
    for i in range(3):
        turn_left()


def turn_arround():
    for i in range(2):
        turn_left()

# don't change this code
if __name__ == '__main__':
    main()