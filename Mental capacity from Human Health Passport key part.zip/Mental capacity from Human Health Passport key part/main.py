import random

CHOICE = [0, 1, 2, 3, 4, 5, 6, 7]



def item1(num3, sample1):
    if num3 in sample1:
        return 0.0
    elif num3 == 8:
        return 0.0
    elif num3 == 9:
        return 0.0
    else:
        return 0.25
    

def item2(num4, sample2):
    if num4 in sample2:
        return 0.0
    if num4 == 8:
        return 0.0
    if num4 == 9:
        return 0.0
    else:
        return 0.25
    

def item3(num5, sample3):
    if num5 in sample3:
        return 0.0
    if num5 == 8:
        return 0.0
    if num5 == 9:
        return 0.0
    else:
        return 0.25
    

def item4(num6, sample4):
    if num6 in sample4:
        return 0.0
    elif num6 == 8:
        return 0.0
    elif num6 == 9:
        return 0.0
    else:
        return 0.25


def main():
    sample1 = random.sample(CHOICE, k=7)
    print(sample1)
    num3 = int(input("What number was missing in each series of seven-digit combinations from 0 to 7? Please enter a number: "))
    result1 = item1(num3, sample1)

    sample2 = random.sample(CHOICE, k=7)
    print(sample2)
    num4 = int(input("What number was missing in each series of seven-digit combinations from 0 to 7? Please enter a number: "))
    result2 = item2(num4, sample2)

    sample3 = random.sample(CHOICE, k=7)
    print(sample3)
    num5 = int(input("What number was missing in each series of seven-digit combinations from 0 to 7? Please enter a number: "))
    result3 = item3(num5, sample3)

    sample4 = random.sample(CHOICE, k=7)
    print(sample4)
    num6 = int(input("What number was missing in each series of seven-digit combinations from 0 to 7? Please enter a number: "))
    result4 = item4(num6, sample4)

    total_score = (result1 + result2 + result3 + result4) * 100
    print("Your results of mental capacity:", total_score, "%!" )

if __name__ == "__main__":
    main()
